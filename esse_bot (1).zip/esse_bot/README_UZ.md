# Esse tekshiruvchi Telegram bot — o‘rnatish yo‘riqnomasi

Bot o‘quvchining essesini **qo‘lyozma (daftar) rasmi yoki matn** ko‘rinishida qabul qiladi va milliy sertifikatning
rasmiy **12 mezoni (24 ball)** bo‘yicha tekshiradi: har bir mezon bo‘yicha taxminiy ball, xatolar (iqtibos → to‘g‘ri varianti),
esse tuzilishi tahlili va maslahatlar beradi. Tekshiruvni Claude (Anthropic API) bajaradi.

## Papka tarkibi
| Fayl | Vazifasi |
|---|---|
| `bot.py` | Telegram bot (muloqot, rasm albomlari, kunlik limit) |
| `checker.py` | Claude bilan ishlash: rasmni o‘qish, baholash, ballarni hisoblash |
| `mezon.md` | Rasmiy baholash mezoni — bot shunga tayanadi |
| `namunalar/` | Namuna esselar (Sohibaning 10 ta 70+ essesi bilan almashtiring) |
| `fmt.py` | Natijani Telegram xabariga aylantirish |
| `test_check.py` | Telegram’siz sinov: `python test_check.py esse.txt` |
| `.env.example` | Sozlamalar namunasi |
| `esse-bot.service` | Serverda doimiy ishlatish uchun (systemd) |

## 1. Kerakli narsalar
1. **Bot tokeni.** Telegramda @BotFather → `/newbot` → nom bering → token beriladi.
2. **Claude API kaliti.** console.anthropic.com → ro‘yxatdan o‘ting → Billing bo‘limida hisobni to‘ldiring → API Keys → yangi kalit.
3. **Server.** Bot kun-u tun ishlashi uchun Ubuntu 22.04+ VPS. 1 vCPU va 1–2 GB RAM yetadi (ovozli xabar qabul qilinmaydi).

Token va kalitni hech kimga yubormang, faqat serverdagi `.env` fayliga yozing.

## 2. Serverga o‘rnatish
```bash
sudo apt update && sudo apt install -y python3-venv
sudo mkdir -p /opt/esse_bot && sudo chown $USER /opt/esse_bot
# papkani kompyuterdan serverga ko‘chiring (masalan):  scp -r esse_bot/* user@SERVER_IP:/opt/esse_bot/
cd /opt/esse_bot
python3 -m venv venv
venv/bin/pip install -r requirements.txt
cp .env.example .env && nano .env      # TELEGRAM_BOT_TOKEN va ANTHROPIC_API_KEY ni yozing
venv/bin/python bot.py                  # sinov: botga /start yozib ko‘ring, Ctrl+C bilan to‘xtating
```

## 3. Doimiy ishlatish
```bash
sudo cp esse-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now esse-bot
sudo systemctl status esse-bot          # holatini ko‘rish
journalctl -u esse-bot -f               # loglarni ko‘rish
```

## 4. Sozlamalar (`.env`)
- `DAILY_LIMIT` — bir o‘quvchiga kuniga nechta tekshiruv (standart 2).
- `GLOBAL_DAILY_CAP` — butun bot uchun kunlik chegara (standart 600). Byudjetdan oshib ketmaslik uchun.
- `MAX_PARALLEL` — bir vaqtda nechta esse tekshiriladi (standart 4). Qolganlar navbatda turadi va o‘rnini ko‘radi.
- `WORK_HOURS` — ish vaqti, Toshkent vaqti bilan (standart `09:00-20:00`). Bo‘sh qoldirilsa, kun-u tun ishlaydi.
- `REQUIRED_CHANNEL` — faqat kanal a’zolari foydalansin desangiz `@kanal_nomi`. Bot shu kanalga **admin** qilib qo‘shilishi kerak.
- `ADMIN_IDS` — limitsiz foydalanadiganlar (Telegram ID; @userinfobot orqali bilish mumkin).
- `CLAUDE_MODEL` — tekshiruvchi model (standart `claude-sonnet-5-5`).

## 5. Admin buyruqlari
- `/stat` — bugungi statistika: tekshiruvlar, foydalanuvchilar, o‘rtacha ball, taxminiy API xarajati. `/stat 7`, `/stat 30` — davr bo‘yicha.
- `/xatolar` — oxirgi 7 kunda eng past mezonlar va eng ko‘p takrorlangan imlo/so‘z xatolari. `/xatolar 30` — 30 kun.

## 6. Namunalarni almashtirish
`namunalar/` papkasidagi `01–05.txt` fayllarni Sohibaning 10 ta 70+ ballik essesi bilan almashtiring (format `namunalar/README.txt`da). Keyin: `sudo systemctl restart esse-bot`.

## 7. Bilish kerak bo‘lgan cheklovlar
- Ball — **taxminiy**, rasmiy natija emas. Bot buni har javobda yozadi.
- Rasmdan o‘qishda ayrim so‘zlar noto‘g‘ri o‘qilishi mumkin — bot o‘qigan matnni o‘quvchiga ko‘rsatadi.
- Har bir tekshiruv Claude API hisobidan pul yechadi (taxminan bir necha sent). Kunlik limit xarajatni nazorat qiladi.
