# -*- coding: utf-8 -*-
"""Telegram'siz sinov: python test_check.py esse.txt [mavzu.txt]"""
import asyncio, sys
from dotenv import load_dotenv
load_dotenv()
import checker, fmt, re

essay = open(sys.argv[1], encoding="utf-8").read()
topic = open(sys.argv[2], encoding="utf-8").read() if len(sys.argv) > 2 else None
res = asyncio.run(checker.evaluate(essay, topic, "matn"))
for p in fmt.render(res):
    print(re.sub(r"<[^>]+>", "", p)); print()
