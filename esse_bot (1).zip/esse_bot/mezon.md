# YOZMA ISH (ESSE)NI BAHOLASH MEZONI — ONA TILI VA ADABIYOT (MILLIY SERTIFIKAT)

Har bir mezon 2; 1,5; 1; 0,5 yoki 0 ball bilan baholanadi. JAMI: 24 BALL.

## TOPSHIRIQ TALABLARINING BAJARILGANLIGI
1. Uslub.
   2 — esse to‘liq publitsistik uslubda yozilgan; 1,5 — ayrim o‘rinlarda publitsistik uslubdan chekinilgan; 1 — esse qisman publitsistik uslubda yozilgan; 0,5 — esse to‘liq badiiy uslubda yozilgan; 0 — esse to‘liq so‘zlashuv uslubida yozilgan.
2. Vaziyatning yoritilishi.
   2 — vaziyat yuzasidan har ikkala qarash hamda talabgorning shaxsiy qarashlari to‘la yoritilgan; 1,5 — har ikkala qarash yoritilgan, talabgorning shaxsiy fikri yoritilmagan; 1 — qarashlarning bittasi to‘la yoritilgan; 0,5 — qarashlarning faqat bittasi qisman yoritilgan; 0 — qarashlar yoritilmagan.
3. Dalillar.
   2 — har ikkala qarash dalillar bilan asoslangan; 1,5 — faqat bitta qarash dalillangan; 1 — har ikkala qarash uchun keltirilgan ayrim dalillar vaziyatga mos emas; 0,5 — har ikkala qarash uchun keltirilgan dalillar vaziyatga mos emas; 0 — har ikkala qarash dalillanmagan.

## MATN YAXLITLIGI (NUTQ KOMPOZITSIYASI, NUTQNING MANTIQIYLIGI)
4. Kirish, asosiy qism va xulosa.
   2 — kirish, asosiy qism va xulosa to‘la yoritib berilgan; 1,5 — esse qismlaridan faqat ikkitasi to‘la yoritilgan; 1 — esse qismlaridan ikkitasi yuza yoritilgan; 0,5 — esse qismlaridan faqat bittasi to‘la yoritilgan; 0 — esse qismlaridan faqat bittasi yuza yoritilgan.
5. Mantiqiy qurilish va xatboshi.
   2 — mantiqiy-qurilish (matn qismlari yoki gap qurilishi)da xatolik kuzatilmagan, esse xatboshilarga ajratilgan; 1,5 — mantiqiy-qurilishda yoki xatboshilarga ajratishda 1–2 o‘rinda xatolik; 1 — 3–4 o‘rinda; 0,5 — 5–6 o‘rinda; 0 — 7 va undan ko‘p o‘rinda xatolik, yoki esse xatboshilarga umuman ajratilmagan.
6. Mantiqiy-mazmuniy izchillik.
   2 — izchillikka to‘liq rioya qilingan, fikrlar takrori yo‘q; 1,5 — fikrlar takrori 1–2 o‘rinda, izchillik buzilmagan; 1 — takror 3–4 o‘rinda, izchillik buzilgan; 0,5 — takror 5–6 o‘rinda, izchillik buzilgan; 0 — takror 7 va undan ortiq o‘rinda, izchillik buzilgan.

## SAVODXONLIK (NUTQNING TO‘G‘RILIGI)
7. Imlo: xato yo‘q — 2; 1–2 — 1,5; 3–4 — 1; 5–6 — 0,5; 7 va undan ortiq — 0.
8. Punktuatsiya: xato yo‘q — 2; 1–2 — 1,5; 3–4 — 1; 5–6 — 0,5; 7 va undan ortiq — 0.

## TIL BIRLIKLARI USLUBIYATI (NUTQNING JO‘YALILIGI)
9. Qo‘shimcha qo‘llash: xato yo‘q — 2; 1–2 — 1,5; 3–4 — 1; 5–6 — 0,5; 7 va undan ortiq — 0.
10. So‘z qo‘llash bilan bog‘liq uslubiy xatolik (so‘zni noto‘g‘ri qo‘llash; noo‘rin takrorlash; ortiqcha qo‘llash; tushirib qoldirish; bog‘lovchi vositalar va kiritmalar bilan bog‘liq xato): yo‘q — 2; 1–2 — 1,5; 3–4 — 1; 5–6 — 0,5; 7 va undan ko‘p — 0.

## LUG‘AT BOYLIGI (NUTQNING BOYLIGI, IFODALILIGI VA SOFLIGI)
11. Leksik xilma-xillik.
   2 — leksik xilma-xillik kuzatilgan: tasviriy ifodalar, vaziyatga mos maxsus leksik birliklar va barqaror birikmalardan unumli foydalanilgan; 1,5 — leksik xilma-xillik kuzatilmagan, bunday birliklardan ayrim o‘rinlarda foydalanilgan; 1 — foydalanilgan, ammo ayrim o‘rinlarda noo‘rin; 0,5 — leksik xilma-xillik kuzatilmagan, bunday birliklardan noo‘rin foydalanilgan; 0 — foydalanilmagan.
12. Nutq sofligi (noo‘rin shevaga oid so‘z yoki qo‘shimcha, vulgarizm, varvarizm, parazit so‘z): uchramaydi — 2; 1–2 o‘rinda, uslubiy g‘alizlik yo‘q — 1,5; 3–4 o‘rinda — 1; 5–6 o‘rinda — 0,5; 7 va undan ko‘p — 0.

## MAXSUS HOLATLAR
- Esse yozilgan, lekin mavzuga mos bo‘lmasa; hajmi 100 ta so‘zdan kam bo‘lsa; boshqa manbadan ko‘chirilgan bo‘lsa — esse tekshirilmaydi va 2 ball bilan baholanadi.
- Esse yozilmagan bo‘lsa — 0 ball.

## ESSE YOZILISHIGA QO‘YILADIGAN TALABLAR
1. Fikr-mulohazalar publitsistik uslubda bayon qilinadi.
2. Fikrlar mantiqiy izchillikda, adabiy til me’yorlariga amal qilgan holda ifodalanadi.
3. Barcha fikr-mulohazalar faqat mavzu doirasida bo‘ladi.
Kirish: ikki-uch jumla; berilgan vaziyat matni aynan ko‘chirilmaydi.
Asosiy qism: kamida uchta xatboshi; har bir xatboshida tomonlarning qarashlari va shaxsiy qarash batafsil yoritiladi; turli qarashlar hayotiy misollar bilan dalillanadi; shaxsiy mulohazalar dalillar asosida yoritiladi.
Xulosa: asosiy qismdagi fikrlar umumlashtiriladi; ikki-uch jumla.
Esse uchun reja tuzilmaydi, epigraf qo‘yilmaydi.
