# -*- coding: utf-8 -*-
"""Esseni Claude orqali o'qish (rasm) va baholash."""
import base64, glob, json, os, re
from anthropic import AsyncAnthropic

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
_client = None


def client():
    global _client
    if _client is None:
        _client = AsyncAnthropic()  # ANTHROPIC_API_KEY muhit o'zgaruvchisidan olinadi
    return _client

MEZON_NOMI = {1: "Uslub", 2: "Vaziyatning yoritilishi", 3: "Dalillar", 4: "Kirish, asosiy qism, xulosa",
              5: "Mantiqiy qurilish va xatboshi", 6: "Mantiqiy-mazmuniy izchillik", 7: "Imlo",
              8: "Punktuatsiya", 9: "Qo‘shimcha qo‘llash", 10: "So‘z qo‘llash", 11: "Leksik xilma-xillik",
              12: "Nutq sofligi"}
SANALADIGAN = (7, 8, 9, 10, 12)  # ball xatolar soniga qarab hisoblanadi


def _namunalar():
    out = []
    for f in sorted(glob.glob(os.path.join(BASE, "namunalar", "*.txt"))):
        out.append(f"--- NAMUNA {os.path.basename(f)} ---\n" + open(f, encoding="utf-8").read().strip())
    return "\n\n".join(out)


SYSTEM = f"""Siz — milliy sertifikat imtihoni uchun ona tili essesini tekshiruvchi tajribali ekspertsiz. Siz Sohiba Gadoyevaning o‘quvchilariga yordam berasiz.
Vazifa: o‘quvchi yozgan esseni quyidagi RASMIY baholash mezoni bo‘yicha xolis tekshirish, xatolarni aniq ko‘rsatish va qanday tuzatishni o‘rgatish.

{open(os.path.join(BASE, 'mezon.md'), encoding='utf-8').read()}

# SOHIBA GADOYEVA USULI (tuzilishni shu tartib bilan solishtiring)
- Kirish: umumiy gap → parafraza (vaziyatni o‘z so‘zlari bilan) → tezis (so‘roq yoki darak gap bo‘lishi mumkin; tezis majburiy emas).
- 1-xatboshi (1-tomon): umumiy gap → fikr → izoh → dalil → fikr → izoh → dalil.
- 2-xatboshi (2-tomon): ikkinchi tomonga o‘tish → fikr → izoh → dalil (ikki marta). Xatboshini «Biroq» bilan boshlash shart emas.
- Dalil fikrni isbotlashi, qisqa bo‘lishi va izoh bilan mantiqan bog‘lanishi kerak; bir-biriga zid dalillar — kamchilik.
- 3-xatboshi «Mening fikrimcha»: faqat BITTA tomon → fikr → izoh → dalil (yangi dalil).
- Xulosa: xulosa gapi (o‘sha tomonni kuchliroq) → yechim/taklif → yakuniy gap. 2–3 jumla.

# YUQORI BALLIK NAMUNALAR (taqqoslash uchun; ulardan ko‘chirilgan esse — «ko‘chirilgan»)
{_namunalar()}

# QOIDALAR
1. Faqat essening o‘zida bor narsani baholang. Xato topsangiz, uni essedan AYNAN iqtibos qiling («matnda» maydoni). Ishonchingiz komil bo‘lmagan joyni xato deb sanamang.
2. O‘zbek adabiy tili (lotin yozuvi) me’yorlariga tayaning. o‘/g‘ uchun ‘, tutuq belgisi uchun ’ ishlatiladi; oddiy ' belgisi bilan yozilgan o‘, g‘ ni imlo xatosi deb SANAMANG (klaviatura cheklovi).
3. Agar manba «rasm» bo‘lsa, matn rasmdan avtomatik o‘qilgan: [?] belgisi va shubhali o‘qilgan so‘zlarni xato deb sanamang.
4. Agar manba «ovoz» bo‘lsa, matn ovozdan avtomatik yozilgan: imlo (7) va punktuatsiya (8) BAHOLANMAYDI (null), xatboshi talabini ham baholamang; so‘z tanib olish xatolarini o‘quvchiga xato sifatida yozmang.
5. Ball faqat 2, 1.5, 1, 0.5 yoki 0 bo‘ladi. 7, 8, 9, 10, 12-mezonlar uchun har bir xatoni «xatolar» ro‘yxatiga alohida yozing — ular soniga qarab ball avtomatik hisoblanadi.
6. Dalillardagi raqam va faktlarni tekshira olmaysiz: agar dalil shubhali yoki o‘ylab topilganga o‘xshasa, buni «maslahatlar»da muloyim eslating, lekin ball pasaytirishga asos qilmang (3-mezon faqat dalil bor-yo‘qligi va vaziyatga mosligini baholaydi).
7. Ohang: samimiy, rag‘batlantiruvchi, aniq. Hech qachon kamsitmang. Javob tili — o‘zbek (lotin).
8. Javobni FAQAT quyidagi JSON ko‘rinishida qaytaring, boshqa hech narsa yozmang:
{{
 "mavzuga_mos": true,
 "kochirilgan": false,
 "mezonlar": [{{"n": 1, "ball": 2, "sabab": "bir gaplik izoh"}}, ... 1 dan 12 gacha hammasi],
 "xatolar": [{{"mezon": 7, "matnda": "imtixon", "togri": "imtihon", "izoh": "h harfi bilan yoziladi"}}],
 "tuzilish": {{"kirish": "...", "birinchi_tomon": "...", "ikkinchi_tomon": "...", "mening_fikrimcha": "...", "xulosa": "..."}},
 "yaxshi_tomonlar": ["...", "..."],
 "maslahatlar": ["eng muhim 2–4 ta aniq maslahat"]
}}"""


def _json(text):
    m = re.search(r"\{.*\}", text, re.S)
    return json.loads(m.group(0))


def shkala75(ball):
    """24 ballik bahoni 75 ballik shkalaga o'tkazadi (jadval: 24→75 ... 2,5→32; har 0,5 ball = 1 ball)."""
    if ball is None:
        return None
    ball = max(0.0, min(24.0, round(ball * 2) / 2))
    return int(round(2 * ball + 27))


def ball_from_count(n):
    return 2 if n == 0 else 1.5 if n <= 2 else 1 if n <= 4 else 0.5 if n <= 6 else 0


def word_count(text):
    return len(re.findall(r"[A-Za-zА-Яа-яЎўҚқҒғҲҳʻʼ‘’'`ʻ-]+", text))


async def read_images(images, kind="esse"):
    """images: [(bytes, 'image/jpeg'), ...] -> matn (xatolari bilan, tuzatilmagan)."""
    content = [{"type": "image", "source": {"type": "base64", "media_type": mt, "data": base64.b64encode(b).decode()}}
               for b, mt in images]
    what = "esse" if kind == "esse" else "esse mavzusi (vaziyat matni)"
    content.append({"type": "text", "text": (
        f"Rasm(lar)da o‘zbek tilida yozilgan {what} bor. Uni AYNAN qanday yozilgan bo‘lsa, shunday ko‘chirib yozing: "
        "imlo, tinish belgisi va grammatik xatolarni TUZATMANG. Xatboshilarni bo‘sh qator bilan saqlang. "
        "O‘qib bo‘lmaydigan so‘z o‘rniga [?] qo‘ying. Bir nechta rasm bo‘lsa, ketma-ketlikda birlashtiring. "
        "Faqat matnni qaytaring, izoh yozmang.")})
    r = await client().messages.create(model=MODEL, max_tokens=3000, messages=[{"role": "user", "content": content}])
    return "".join(b.text for b in r.content if b.type == "text").strip()


async def evaluate(essay, topic=None, source="matn"):
    wc = word_count(essay)
    if wc < 100:
        return {"maxsus": f"Essening hajmi {wc} ta so‘z. Rasmiy mezonga ko‘ra, 100 ta so‘zdan kam esse tekshirilmaydi va 2 ball bilan baholanadi. Esseni to‘liq yozib, qayta yuboring.", "soz_soni": wc}
    user = (f"MANBA: {source}\nMAVZU (vaziyat): {topic or 'berilmagan — mavzuni essening o‘zidan aniqlang, 2-mezonda buni hisobga oling'}\n"
            f"SO‘ZLAR SONI: {wc}\n\nO‘QUVCHI ESSESI:\n{essay}")
    r = await client().messages.create(
        model=MODEL, max_tokens=4000,
        system=[{"type": "text", "text": SYSTEM, "cache_control": {"type": "ephemeral"}}],
        messages=[{"role": "user", "content": user}])
    data = _json("".join(b.text for b in r.content if b.type == "text"))
    data["soz_soni"] = wc
    u = getattr(r, "usage", None)
    if u:
        data["_tok"] = {"in": (u.input_tokens or 0) + (getattr(u, "cache_creation_input_tokens", 0) or 0),
                        "cache": getattr(u, "cache_read_input_tokens", 0) or 0, "out": u.output_tokens or 0}
    return finalize(data, source)


def finalize(data, source="matn"):
    """Ballarni rasmiy qoidaga keltiradi va jamini hisoblaydi."""
    if not data.get("mavzuga_mos", True) or data.get("kochirilgan"):
        data["maxsus"] = ("Esse mavzuga mos emas." if not data.get("mavzuga_mos", True) else "Esse boshqa manbadan ko‘chirilganga o‘xshaydi.") + \
                         " Rasmiy mezonga ko‘ra, bunday esse tekshirilmaydi va 2 ball bilan baholanadi."
    by_n = {int(m["n"]): m for m in data.get("mezonlar", [])}
    errs = data.get("xatolar", [])
    for n in SANALADIGAN:
        m = by_n.setdefault(n, {"n": n, "sabab": ""})
        cnt = sum(1 for e in errs if int(e.get("mezon", 0)) == n)
        m["ball"] = ball_from_count(cnt)
        m["xato_soni"] = cnt
    if source == "ovoz":
        for n in (7, 8):
            by_n[n]["ball"] = None
            by_n[n]["sabab"] = "Ovozli esseda baholanmaydi."
    for n in range(1, 13):
        by_n.setdefault(n, {"n": n, "ball": 0, "sabab": "Baholanmadi."})
    data["mezonlar"] = [by_n[n] for n in range(1, 13)]
    scored = [m["ball"] for m in data["mezonlar"] if m["ball"] is not None]
    data["jami"] = sum(scored)
    data["maks"] = 2 * len(scored)
    # 75 ballik shkala faqat to'liq (24 ballik) baholashda hisoblanadi
    data["shkala75"] = shkala75(data["jami"]) if data["maks"] == 24 and not data.get("maxsus") else None
    return data


async def clean_voice(raw):
    """Ovozdan avtomatik yozilgan xom matnni o'zbek lotin imlosiga keltiradi (mazmun va so'z tartibi o'zgarmaydi)."""
    r = await client().messages.create(model=MODEL, max_tokens=3000, messages=[{"role": "user", "content": (
        "Quyida o‘zbek tilidagi ovozli xabardan avtomatik yozib olingan xom matn bor. Unda so‘zlar talaffuz bo‘yicha "
        "noto‘g‘ri yozilgan bo‘lishi mumkin (masalan, «imtiqan» — «imtihon»). Matnni to‘g‘ri o‘zbek lotin imlosiga keltiring: "
        "so‘zlarni to‘g‘ri yozing va gaplarga ajrating. Mazmunni, so‘z tanlovini va gap tartibini O‘ZGARTIRMANG, hech narsa "
        "qo‘shmang va olib tashlamang. Faqat tayyor matnni qaytaring.\n\nXOM MATN:\n" + raw)}])
    return "".join(b.text for b in r.content if b.type == "text").strip()
