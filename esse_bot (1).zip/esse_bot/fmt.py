# -*- coding: utf-8 -*-
"""Natijani Telegram uchun chiroyli xabarga aylantirish (HTML)."""
from html import escape as e
from checker import MEZON_NOMI


def _b(x):
    return "—" if x is None else (f"{x:g}".replace(".", ","))


def _icon(x):
    return "⚪️" if x is None else "✅" if x >= 2 else "🟡" if x >= 1 else "🔴"


def render(d):
    if d.get("maxsus") and "mezonlar" not in d:
        return [f"⚠️ {e(d['maxsus'])}"]
    out = []
    head = f"📝 <b>Esse natijasi</b>\nTaxminiy ball: <b>{_b(d['jami'])} / {d['maks']}</b> · So‘zlar: {d.get('soz_soni')}"
    if d.get("shkala75") is not None:
        head += f"\n📊 75 ballik shkalada: <b>≈ {d['shkala75']} ball</b> (taxminiy)"
    if d.get("maxsus"):
        head += f"\n\n⚠️ {e(d['maxsus'])}"
    lines = [head, "", "<b>Mezonlar bo‘yicha:</b>"]
    for m in d["mezonlar"]:
        extra = f" ({m['xato_soni']} ta xato)" if m.get("xato_soni") else ""
        lines.append(f"{_icon(m['ball'])} {m['n']}. {MEZON_NOMI[m['n']]} — <b>{_b(m['ball'])}</b>{extra}")
        if m.get("sabab") and (m["ball"] is None or m["ball"] < 2):
            lines.append(f"    <i>{e(m['sabab'])}</i>")
    out.append("\n".join(lines))

    errs = d.get("xatolar") or []
    if errs:
        ls = ["❌ <b>Xatolar va to‘g‘ri varianti:</b>"]
        for x in sorted(errs, key=lambda x: int(x.get("mezon", 0))):
            nm = MEZON_NOMI.get(int(x.get("mezon", 0)), "")
            ls.append(f"• «{e(str(x.get('matnda','')))}» → <b>{e(str(x.get('togri','')))}</b>  <i>({x.get('mezon')}-mezon, {e(nm)})</i>")
            if x.get("izoh"):
                ls.append(f"   {e(x['izoh'])}")
        out.append("\n".join(ls))

    t = d.get("tuzilish") or {}
    if t:
        names = [("kirish", "Kirish"), ("birinchi_tomon", "1-tomon"), ("ikkinchi_tomon", "2-tomon"),
                 ("mening_fikrimcha", "Mening fikrimcha"), ("xulosa", "Xulosa")]
        out.append("🧱 <b>Tuzilish:</b>\n" + "\n".join(f"• <b>{n}:</b> {e(t[k])}" for k, n in names if t.get(k)))

    tail = []
    if d.get("yaxshi_tomonlar"):
        tail.append("👍 <b>Yaxshi tomonlari:</b>\n" + "\n".join(f"• {e(x)}" for x in d["yaxshi_tomonlar"]))
    if d.get("maslahatlar"):
        tail.append("💡 <b>Keyingi safar:</b>\n" + "\n".join(f"{i}. {e(x)}" for i, x in enumerate(d["maslahatlar"], 1)))
    tail.append("<i>Bu sun’iy intellekt bergan taxminiy baho, rasmiy natija emas.</i>")
    out.append("\n\n".join(tail))
    return split(out)


def split(parts, limit=3900):
    res = []
    for p in parts:
        while len(p) > limit:
            cut = p.rfind("\n", 0, limit)
            cut = cut if cut > 0 else limit
            res.append(p[:cut]); p = p[cut:]
        res.append(p)
    return res
