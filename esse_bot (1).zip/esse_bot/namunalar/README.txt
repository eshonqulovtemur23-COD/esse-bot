Bu papkaga yuqori ballik (70+) namuna esselar qo'yiladi. Bot ular bilan solishtirib tekshiradi.
Hozirgi 01–05.txt — "Esse bo'yicha qo'llanma" kitobidan vaqtincha olingan namunalar.
Sohibaning 10 ta namunasi bilan almashtiring.

Har bir fayl formati (UTF-8, .txt):
1-qator: MAVZU: <imtihondagi vaziyat matni>
2-qator: bo'sh
Keyin esse matni, xatboshilar orasida bitta bo'sh qator.
Fayllarni o'zgartirgandan keyin botni qayta ishga tushiring.
