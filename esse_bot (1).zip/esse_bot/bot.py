# -*- coding: utf-8 -*-
"""Sohiba Gadoyeva — esse tekshiruvchi Telegram bot (namunaviy versiya).

Ishlash tartibi:
  /start → (ixtiyoriy) mavzu matni yoki rasmi → esse: matn yoki daftar rasmi → natija.
"""
import asyncio, datetime, json, logging, os, sqlite3, tempfile
from collections import Counter
from zoneinfo import ZoneInfo
from dotenv import load_dotenv

load_dotenv()

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode, ChatAction
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters)

import checker, fmt

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("esse_bot")

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
DAILY_LIMIT = int(os.getenv("DAILY_LIMIT", "2"))            # bir o'quvchiga kuniga
GLOBAL_DAILY_CAP = int(os.getenv("GLOBAL_DAILY_CAP", "600"))  # butun bot uchun kuniga (byudjet himoyasi)
MAX_PARALLEL = int(os.getenv("MAX_PARALLEL", "4"))           # bir vaqtda nechta esse tekshiriladi
WORK_HOURS = os.getenv("WORK_HOURS", "09:00-20:00").strip()  # bo'sh qoldirilsa — kun-u tun
REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "").strip()  # masalan: @sohiba_kanal (bo'sh bo'lsa — tekshirilmaydi)
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").replace(" ", "").split(",") if x}
PRICE_IN, PRICE_OUT, PRICE_CACHE = (float(os.getenv(k, d)) for k, d in
                                    (("PRICE_IN", "2"), ("PRICE_OUT", "10"), ("PRICE_CACHE", "0.1")))  # $ / 1M token
TZ = ZoneInfo("Asia/Tashkent")
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot.db")
SEM = asyncio.Semaphore(MAX_PARALLEL)
WAITING = 0  # navbatda turganlar soni


def now():
    return datetime.datetime.now(TZ)


def today():
    return str(now().date())


# ---------- baza ----------
def _db():
    c = sqlite3.connect(DB)
    c.execute("create table if not exists usage(user_id integer, day text, n integer, primary key(user_id, day))")
    c.execute("create table if not exists users(user_id integer primary key, username text, name text, first_seen text)")
    c.execute("""create table if not exists checks(id integer primary key autoincrement, user_id integer, ts text, day text,
                 source text, words integer, jami real, maks real, b75 integer, special text,
                 mezon_json text, errors_json text, tok_in integer, tok_cache integer, tok_out integer)""")
    return c


def remember_user(u):
    with _db() as c:
        c.execute("insert or ignore into users values(?,?,?,?)",
                  (u.id, u.username or "", u.full_name or "", now().isoformat(timespec="seconds")))


def used_today(uid):
    with _db() as c:
        r = c.execute("select n from usage where user_id=? and day=?", (uid, today())).fetchone()
    return r[0] if r else 0


def total_today():
    with _db() as c:
        return c.execute("select coalesce(sum(n),0) from usage where day=?", (today(),)).fetchone()[0]


def add_use(uid):
    with _db() as c:
        c.execute("insert into usage values(?,?,1) on conflict(user_id,day) do update set n=n+1", (uid, today()))


def log_check(uid, source, res):
    tok = res.get("_tok", {})
    mez = {m["n"]: m["ball"] for m in res.get("mezonlar", [])}
    errs = [{"m": x.get("mezon"), "x": x.get("matnda"), "t": x.get("togri")} for x in res.get("xatolar", [])]
    with _db() as c:
        c.execute("insert into checks(user_id,ts,day,source,words,jami,maks,b75,special,mezon_json,errors_json,"
                  "tok_in,tok_cache,tok_out) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (uid, now().isoformat(timespec="seconds"), today(), source, res.get("soz_soni"), res.get("jami"),
                   res.get("maks"), res.get("shkala75"), res.get("maxsus"), json.dumps(mez), json.dumps(errs, ensure_ascii=False),
                   tok.get("in", 0), tok.get("cache", 0), tok.get("out", 0)))


def in_work_hours():
    if not WORK_HOURS:
        return True
    a, b = WORK_HOURS.split("-")
    t = now().strftime("%H:%M")
    return a <= t < b


# ---------- matnlar ----------
START = ("Assalomu alaykum! 👋\n\nMen <b>Sohiba Gadoyeva</b>ning esse tekshiruvchi botiman. "
         "Esseingizni milliy sertifikatning rasmiy <b>12 mezoni (24 ball)</b> bo‘yicha tekshirib, "
         "xatolaringizni va ularni qanday tuzatishni ko‘rsataman.\n\n"
         "<b>1-qadam.</b> Esse <b>mavzusini</b> (vaziyat matnini) yuboring — matn yoki rasm.\n"
         "<b>2-qadam.</b> <b>Esseingizni</b> yuboring — daftarga yozganingizni rasmga olib "
         "(bir nechta bet bo‘lsa, bitta albom qilib) yoki matn qilib.\n\n"
         "Mavzu qo‘lingizda bo‘lmasa, pastdagi tugmani bosing.")
ASK_ESSAY = "✅ Mavzu qabul qilindi.\n\nEndi <b>esseingizni</b> yuboring: daftar rasmi yoki matn."
KB_SKIP = InlineKeyboardMarkup([[InlineKeyboardButton("Mavzusiz tekshirish", callback_data="skip")]])
KB_NEW = InlineKeyboardMarkup([[InlineKeyboardButton("✍️ Yangi esse tekshirish", callback_data="new")]])


# ---------- yordamchilar ----------
async def allowed(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user = update.effective_user
    uid = user.id
    remember_user(user)
    if uid in ADMIN_IDS:
        return True
    chat = update.effective_chat
    if not in_work_hours():
        await chat.send_message(f"🕘 Bot esselarni soat {WORK_HOURS.replace('-', ' dan ')} gacha tekshiradi. "
                                "Shu vaqt oralig‘ida qayta yuboring.")
        return False
    if REQUIRED_CHANNEL:
        try:
            m = await context.bot.get_chat_member(REQUIRED_CHANNEL, uid)
            if m.status in ("left", "kicked"):
                await chat.send_message(
                    f"Botdan foydalanish uchun avval {REQUIRED_CHANNEL} kanaliga a’zo bo‘ling, so‘ng /start bosing.")
                return False
        except Exception as ex:  # bot kanalga admin qilinmagan bo'lishi mumkin
            log.warning("kanal tekshiruvi xatosi: %s", ex)
    if used_today(uid) >= DAILY_LIMIT:
        await chat.send_message(f"Bugun {DAILY_LIMIT} ta esse tekshirdingiz — bu kunlik limit. Ertaga yana yuboring. 🙂")
        return False
    if total_today() >= GLOBAL_DAILY_CAP:
        await chat.send_message("Bugungi tekshiruvlar soni to‘ldi. Iltimos, ertaga yuboring. 🙂")
        return False
    return True


async def send_parts(chat, parts):
    for p in parts:
        await chat.send_message(p, parse_mode=ParseMode.HTML, disable_web_page_preview=True)


async def run_check(update: Update, context: ContextTypes.DEFAULT_TYPE, essay: str, source: str, checked=False):
    global WAITING
    chat = update.effective_chat
    if not checked and not await allowed(update, context):
        return
    if context.user_data.get("busy"):
        await chat.send_message("Oldingi esseingiz hali tekshirilmoqda, natijani kuting.")
        return
    context.user_data["busy"] = True
    try:
        if SEM.locked():
            WAITING += 1
            wait = await chat.send_message(f"⏳ Navbatdasiz ({WAITING}-o‘rin). Navbatingiz kelganda tekshiruv boshlanadi.")
            try:
                await SEM.acquire()
            finally:
                WAITING -= 1
            await wait.edit_text("⏳ Esse tekshirilmoqda, 20–40 soniya kuting…")
        else:
            await SEM.acquire()
            wait = await chat.send_message("⏳ Esse tekshirilmoqda, 20–40 soniya kuting…")
        try:
            await chat.send_action(ChatAction.TYPING)
            res = await checker.evaluate(essay, context.user_data.get("topic"), source)
        except Exception:
            log.exception("baholash xatosi")
            await wait.edit_text("Kechirasiz, tekshirishda xatolik yuz berdi. Birozdan so‘ng qayta urinib ko‘ring.")
            return
        finally:
            SEM.release()
        if "mezonlar" in res:
            add_use(update.effective_user.id)
        try:
            log_check(update.effective_user.id, source, res)
        except Exception:
            log.exception("statistika yozish xatosi")
        await wait.delete()
        await send_parts(chat, fmt.render(res))
        await chat.send_message("Yana tekshiramizmi?", reply_markup=KB_NEW)
    finally:
        context.user_data.clear()


# ---------- admin ----------
def _period(arg):
    days = int(arg) if arg and arg.isdigit() else 1
    start = str((now() - datetime.timedelta(days=days - 1)).date())
    return days, start


async def stat_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return
    days, start = _period(context.args[0] if context.args else "")
    with _db() as c:
        n, users, avg24, avg75, ti, tc, to = c.execute(
            "select count(*), count(distinct user_id), avg(case when maks=24 then jami end), avg(b75),"
            " coalesce(sum(tok_in),0), coalesce(sum(tok_cache),0), coalesce(sum(tok_out),0) from checks where day>=?",
            (start,)).fetchone()
        src = c.execute("select source, count(*) from checks where day>=? group by source", (start,)).fetchall()
        allu = c.execute("select count(*) from users").fetchone()[0]
        newu = c.execute("select count(*) from users where substr(first_seen,1,10)>=?", (start,)).fetchone()[0]
    cost = (ti * PRICE_IN + to * PRICE_OUT + tc * PRICE_CACHE) / 1e6
    f = lambda x: "—" if x is None else f"{x:.1f}".replace(".", ",")
    txt = (f"📊 <b>Statistika</b> ({'bugun' if days == 1 else f'oxirgi {days} kun'})\n\n"
           f"Tekshiruvlar: <b>{n}</b>\nFoydalanuvchilar: <b>{users}</b> (yangi: {newu}, jami: {allu})\n"
           f"O‘rtacha ball: <b>{f(avg24)}</b> / 24 · ≈ {f(avg75)} / 75\n"
           f"Manba: " + (", ".join(f"{s} — {k}" for s, k in src) or "—") +
           f"\nTaxminiy API xarajati (faqat baholash): <b>${cost:.2f}</b>\n\n"
           "<i>Davr: /stat 7 yoki /stat 30. Xatolar: /xatolar 7</i>")
    await update.message.reply_text(txt, parse_mode=ParseMode.HTML)


async def xatolar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return
    days, start = _period(context.args[0] if context.args else "7")
    with _db() as c:
        rows = c.execute("select mezon_json, errors_json from checks where day>=? and maks=24", (start,)).fetchall()
    if not rows:
        await update.message.reply_text("Bu davrda tekshiruv yo‘q.")
        return
    sums, cnt, per_m, words = Counter(), Counter(), Counter(), Counter()
    for mj, ej in rows:
        for k, v in json.loads(mj).items():
            if v is not None:
                sums[int(k)] += v; cnt[int(k)] += 1
        for x in json.loads(ej):
            per_m[x.get("m")] += 1
            if x.get("m") in (7, 9, 10) and x.get("x"):
                words[f"{x['x']} → {x.get('t') or '?'}"] += 1
    weak = sorted(((sums[k] / cnt[k], k) for k in cnt))[:5]
    lines = [f"🔎 <b>Takrorlanuvchi xatolar</b> (oxirgi {days} kun, {len(rows)} ta esse)", "",
             "<b>Eng past mezonlar</b> (o‘rtacha ball / 2):"]
    lines += [f"• {checker.MEZON_NOMI[k]} — {a:.2f}".replace(".", ",") for a, k in weak]
    lines += ["", "<b>Xatolar soni mezon bo‘yicha:</b>"]
    lines += [f"• {checker.MEZON_NOMI.get(m, m)} — {k} ta" for m, k in per_m.most_common(6)]
    if words:
        lines += ["", "<b>Eng ko‘p uchragan imlo/so‘z xatolari:</b>"]
        lines += [f"• {fmt.e(w)} — {k} marta" for w, k in words.most_common(15)]
    await send_parts(update.effective_chat, fmt.split(["\n".join(lines)]))


# ---------- handlerlar ----------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    context.user_data["stage"] = "topic"
    await update.effective_chat.send_message(START, parse_mode=ParseMode.HTML, reply_markup=KB_SKIP)


async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "skip":
        context.user_data["stage"] = "essay"
        context.user_data.pop("topic", None)
        await q.message.reply_text("Yaxshi. Endi <b>esseingizni</b> yuboring: daftar rasmi yoki matn.",
                                   parse_mode=ParseMode.HTML)
    elif q.data == "new":
        await start(update, context)


async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    stage = context.user_data.get("stage", "topic")
    if stage == "topic" and len(text.split()) < 100:
        context.user_data["topic"] = text
        context.user_data["stage"] = "essay"
        await update.message.reply_text(ASK_ESSAY, parse_mode=ParseMode.HTML)
        return
    await run_check(update, context, text, "matn")


async def _photo_bytes(context, photo):
    f = await context.bot.get_file(photo.file_id)
    return bytes(await f.download_as_bytearray())


async def on_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    data = await _photo_bytes(context, msg.photo[-1])
    gid = msg.media_group_id
    if gid:  # albom: hamma rasmlar kelguncha kutamiz
        buf = context.user_data.setdefault("album", {}).setdefault(gid, [])
        buf.append((msg.message_id, data))
        for j in context.job_queue.get_jobs_by_name(f"album_{gid}"):
            j.schedule_removal()
        context.job_queue.run_once(album_done, 2.5, name=f"album_{gid}",
                                   data={"gid": gid, "update": update}, user_id=update.effective_user.id,
                                   chat_id=update.effective_chat.id)
        return
    await handle_images(update, context, [data])


async def album_done(context: ContextTypes.DEFAULT_TYPE):
    gid = context.job.data["gid"]
    update = context.job.data["update"]
    items = context.user_data.get("album", {}).pop(gid, [])
    items.sort(key=lambda x: x[0])
    await handle_images(update, context, [b for _, b in items])


async def handle_images(update: Update, context: ContextTypes.DEFAULT_TYPE, blobs):
    chat = update.effective_chat
    stage = context.user_data.get("stage", "topic")
    kind = "mavzu" if stage == "topic" else "esse"
    if kind == "esse" and not await allowed(update, context):
        return
    wait = await chat.send_message("📷 Rasmdagi matnni o‘qiyapman…")
    try:
        text = await checker.read_images([(b, "image/jpeg") for b in blobs], kind)
    except Exception:
        log.exception("rasm o'qish xatosi")
        await wait.edit_text("Rasmni o‘qib bo‘lmadi. Yorug‘roq joyda, tekis qilib qayta suratga oling.")
        return
    await wait.delete()
    if kind == "mavzu" and len(text.split()) >= 100:  # mavzu o'rniga darhol esse yuborilgan
        kind = "esse"
        if not await allowed(update, context):
            return
    if kind == "mavzu":
        context.user_data["topic"] = text
        context.user_data["stage"] = "essay"
        await chat.send_message(f"📌 <b>Mavzu:</b>\n{fmt.e(text)}\n\n" + ASK_ESSAY, parse_mode=ParseMode.HTML)
        return
    await send_parts(chat, fmt.split([f"📷 <b>Rasmdan o‘qilgan matn</b> (to‘g‘ri o‘qilganini tekshiring):\n\n{fmt.e(text)}"]))
    await run_check(update, context, text, "rasm", checked=True)


async def on_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_chat.send_message(
        "Ovozli xabar qabul qilinmaydi. Esseni daftarga yozib, <b>rasmga olib</b> yuboring "
        "(bir nechta bet bo‘lsa — bitta albom qilib).", parse_mode=ParseMode.HTML)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(START, parse_mode=ParseMode.HTML)


def build_app(token):
    app = Application.builder().token(token).concurrent_updates(True).build()
    app.add_handler(CommandHandler(["start", "yangi"], start))
    app.add_handler(CommandHandler("yordam", help_cmd))
    app.add_handler(CommandHandler("stat", stat_cmd))
    app.add_handler(CommandHandler("xatolar", xatolar_cmd))
    app.add_handler(CallbackQueryHandler(buttons))
    app.add_handler(MessageHandler(filters.PHOTO, on_photo))
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, on_voice))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    return app


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("TELEGRAM_BOT_TOKEN .env faylida ko‘rsatilmagan")
    build_app(TOKEN).run_polling(allowed_updates=Update.ALL_TYPES)
